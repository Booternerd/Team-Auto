function [X,Y] = getP2(x,y,Pz)

load('c2g2.mat');

% x,y pixel coordinate of undistorted image

% if Pz is on the table region (i.e. Pz = 347)

if Pz == 247
    
    xt = xv + x*cos(CAng) + y*sin(CAng);
    yt = yv + y*cos(CAng) - x*sin(CAng);

    X = (xt - xo)*xp2mmT;
    Y = (yt - yo)*yp2mmT;
    
else

% if Pz is on the conveyer region (i.e. Pz = 122.1)
if Pz == 122.1
    
    xt = xv + x*cos(CAng) + y*sin(CAng);
    yt = yv + y*cos(CAng) - x*sin(CAng);

    X = (xt - xo)*xp2mmC;
    Y = (yt - yo)*yp2mmC;
    
else
    X = [];
    Y = [];
    fprintf('Coordinates clicked are out of area\n');
end;
end;

return;

end