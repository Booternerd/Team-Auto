command{10,1}=[];
% comman
command(2)=command(1);
command(3)=command(2);
command(4)=command(3);
command(5)=command(4);
command(6)=command(5);
command(7)=command(6);
command(8)=command(7);
command(9)=command(8);
command(10)=command(9);
command(1)=cellstr('123456')